<?php
	$this->_pageTitle = 'Title';
	$this->_activeMenu = 'example-page-1';
?>
<section id="middle">

	<div class="headline">
		<h1>Title</h1>
	</div>
	<div class="cmsms_breadcrumbs">
		<a href="Index/index" class="cms_home">Home</a>
		<span class="breadcrumbs_sep">/</span>
		<span>Title</span>
	</div>
	

	<div class="content_wrap fullwidth">

		Your content here...

		<div class="cl"></div>
	</div>
</section>