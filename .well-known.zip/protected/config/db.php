<?php            
return array(
    // database settings
    'db' => array(
        'driver' 	=> 'mysql',
		'socket' 	=> '',
        'host' 		=> 'localhost',
		'port' 		=> '',
        'database' 	=> 'yaufania_bpkh',
        'username' 	=> 'yaufania_bpkhu',
        'password' 	=> 'LkFC.~bDSj7m',
        'prefix' 	=> 'bpk_',
        'charset' 	=> 'utf8',
        'schema' 	=> ''
    )               
);