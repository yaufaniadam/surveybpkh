<?php

return array(
    // Module classes
    'classes' => array(
        'Setup'
    )
);
