<?php 
    $this->_pageTitle = '';
    
    if(!isset($title)) $title = '';
    if(!isset($text)) $text = '';
?>

<h1 class="title"><?= $title; ?></h1>
<div class="block-body">
    
    <?= $text; ?>
    
    <img src="https://seeklogo.com/images/G/garuda-pancasila-logo-30B3C3EE1D-seeklogo.com.png" width="80" height="" />
    <br><br>
    
    <h2>Selamat Datang di Survei Identitas<br>Badan Pengelola Keuangan Haji Republik Indonesia</h2>
    <br>
    
    <p><em>Assalamu’alaikum Warahmatullahi Wabarakatuh</em></p>
    <p>Dengan Hormat,</p>
    
    <p style="text-align:justify;">Dalam rangka meningkatkan kinerja Badan Pengelola Keuangan Haji (BPKH), mohon kesediaan Saudara untuk menjawab beberapa pertanyaan berikut ini<br></b> Jawaban Saudara sangat berharga bagi kami untuk melakukan evaluasi dan perbaikan kinerja. </p>
    <p>Atas kesediaan Saudara meluangkan waktu dan mengisi kuesioner ini diucapkan banyak terima kasih. </p>
    
    <p><strong>Catatan:</strong>
        Semua identitas dan jawaban dijamin kerahasiaanya dan hanya digunakan unt kepentingan survei ini dan tidak diberikan pada pihak lain.</p>
       
    <p><em>Wassalamu’alaikum Warahmatullahi Wabarakatuh</em></p>

    Hormat Kami,<br>
    <br><br>
    Pengurus BPKH
    <br>
    <hr>
    
    
    <a href="http://www.bpkh.site/surveys/show/code/2" /> Mulai Survei </a>

</div>
