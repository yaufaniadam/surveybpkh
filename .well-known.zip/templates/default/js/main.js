$(document).ready(function(){

    // INIT TOOLTIPS
    // --------------------------------------
    $('.tooltip-icon').tipTip({maxWidth: '270px', edgeOffset: 10}); /* maxWidth: 'auto' */
    $('.tooltip-link').tipTip({maxWidth: '270px', edgeOffset: 10});

    
})    